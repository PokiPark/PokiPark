package application;

import java.io.*;
import java.sql.*;
import java.util.*;
import java.util.regex.*;

import POJO.User;
import javafx.event.*;
import javafx.fxml.*;
import javafx.scene.control.*;
import javafx.scene.layout.*;

public class RegisterController {

	@FXML
	private AnchorPane rootPane;

	@FXML
	private Label error_L;

	@FXML
	private TextField username_TF, email_TF;

	@FXML
	private PasswordField password_PF, passwordCheck_PF;

	// START OF FXML-METHODS //

	@FXML
	private void register_B_Action(ActionEvent event) throws SQLException, IOException {
		
		String username = username_TF.getText().toString();
		String email = email_TF.getText().toString();
		String password = password_PF.getText().toString();
		String passwordCheck = passwordCheck_PF.getText().toString();
		
		if (registerDataIsValid(username, email, password, passwordCheck)) {
			
			Database.sendSqlCommand("INSERT INTO usertable (username, password, email, id, admin) VALUES ('"
					+ username + "', '" + password + "','" + email + "', NULL, 0);");
			
			error_L.setText("");
			
			AnchorPane pane = FXMLLoader.load(getClass().getResource("Login.fxml"));
			rootPane.getChildren().setAll(pane);
		}
	}

	@FXML
	private void login_HL_Action(ActionEvent event) throws IOException {
		
		AnchorPane pane = FXMLLoader.load(getClass().getResource("Login.fxml"));
		rootPane.getChildren().setAll(pane);
	}

	// END OF FXML-METHODS //, String 
	
	private boolean registerDataIsValid(String username, String email, String password, String passwordCheck)
			throws SQLException {

		Database.initData("usertable");
		ArrayList<User> userlist = Database.getUserlist();

		if (username.isEmpty() || email.isEmpty() || password.isEmpty() || passwordCheck.isEmpty()) {
			
			error_L.setText("Gehe sicher, dass alle Felder ausgef�llt sind.");
			return false;

		} else if (!usernameIsValid(userlist, username)) {
			
			error_L.setText("Benutzername wird bereits verwendet.");
			return false;

		} else if (!emailIsValid(userlist, email)) {
			
			error_L.setText("Email wird bereits verwendet.");
			return false;

		} else if (!emailHasCorrectSemantics(email)) {
			
			error_L.setText("Email ist ung�ltig. Achte darauf, dass [@ und .] verwendet werden.");
			return false;

		} else if (!passwordIsValid(password)) {
			
			error_L.setText("Passwort ben�tigt min. 8 Zeichen; Gro�- & Kleinbuchstaben, Zahlen und Sonderzeichen.");
			return false;

		} else if (!passwordsMatch(password, passwordCheck)) {
			
			error_L.setText("Passw�rter stimmen nicht �berein.");
			return false;

		} else
			return true;
	}

	public boolean usernameIsValid(ArrayList<User> userlist, String username) {
		boolean usernameIsValid = true;

		for (int i = 0; i < userlist.size() & usernameIsValid; i++) {

			if (userlist.get(i).getUsername().equals(username))
				usernameIsValid = false;
		}
		return usernameIsValid;
	}

	public boolean emailIsValid(ArrayList<User> userlist, String email) {
		boolean emailIsValid = true;

		for (int i = 0; i < userlist.size() & emailIsValid; i++) {

			if (userlist.get(i).getEmail().equals(email))
				emailIsValid = false;
		}
		return emailIsValid;
	}

	public boolean emailHasCorrectSemantics(String email) {
		Pattern at = Pattern.compile("[@]");
		Pattern dot = Pattern.compile("[.]");
		Matcher hasAt = at.matcher(email);
		Matcher hasDot = dot.matcher(email);

		if (hasAt.find() & hasDot.find())
			return true;
		else
			return false;
	}

	public boolean passwordIsValid(String password) {
		// @Author
		// https://stackoverflow.com/questions/1795402/check-if-a-string-contains-a-special-character
		if (password.length() >= 8) {

			Pattern letters = Pattern.compile("[a-zA-Z]");
			Pattern numbers = Pattern.compile("[0-9]");
			Pattern specials = Pattern.compile("[!@#$%&*()_+=|<>?{}\\\\[\\\\]~-]");

			Matcher hasLetters = letters.matcher(password);
			Matcher hasNumbers = numbers.matcher(password);
			Matcher hasSpecials = specials.matcher(password);

			return hasLetters.find() && hasNumbers.find() && hasSpecials.find();

		} else
			return false;
	}

	private boolean passwordsMatch(String password, String passwordCheck) {
		if (password.equals(passwordCheck))
			return true;

		else
			return false;
	}
}